# Results

This directory contains the evaluation outputs used in the reported experiments.

## primary

`raw`, `tempered`, and `full` contain seed-level evaluation episodes, per-seed summaries, dual trajectories, and training metadata for seeds 0--9. `all_evaluation_episodes.csv` and `seed_level_means.csv` combine the primary evaluation data across all variants and seeds.

## cmars_adapted

Contains evaluation outputs for the five matched CMARS-inspired baseline seeds (0--4), together with the combined episode-level data and seed-level means.

## generalization

Contains frozen-policy evaluation data under the six unseen load, stress, and capacity shifts, together with the scenario definition, summary tables, hierarchical confidence intervals, and paired tests.

## inference

Contains the CPU-only inference benchmark output for the 72-dimensional tempered SAC actor.

Trained policy checkpoints, replay buffers, manuscript files, and LaTeX sources are intentionally not included. The training scripts can regenerate policy checkpoints when needed.
